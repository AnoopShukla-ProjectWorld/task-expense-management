import Modal from "../common/Modal";
import Input from "../common/Input";
import Button from "../common/Button";

function UserModal({ isOpen, onClose }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <h2 className="text-xl font-bold mb-5">
        Create User
      </h2>

      <div className="space-y-4">
        <Input label="Full Name" placeholder="Enter full name" />
        <Input label="Email" type="email" placeholder="Enter email" />
        <Input label="Password" type="password" placeholder="Enter password" />

        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-gray-700">
            Role
          </label>
          <select className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500">
            <option value="ADMIN">Admin</option>
            <option value="MANAGER">Manager</option>
            <option value="EMPLOYEE">Employee</option>
          </select>
        </div>

        <Button className="w-full">
          Create User
        </Button>
      </div>
    </Modal>
  );
}

export default UserModal;