import {
  useMemo,
  useState,
} from "react";

import {
  FaSort,
  FaEdit,
  FaTrash,
} from "react-icons/fa";

import EmptyState from "../common/EmptyState";

import TableLoader from "../loaders/TableLoader";

function DataTable({
  columns = [],
  data = [],
  loading = false,

  actions = false,

  onEdit,
  onDelete,
}) {
  const [sortKey, setSortKey] =
    useState("");

  const [sortOrder, setSortOrder] =
    useState("asc");

  const [selectedRows, setSelectedRows] =
    useState([]);

  const sortedData = useMemo(() => {
    if (!sortKey) return data;

    return [...data].sort((a, b) => {
      if (sortOrder === "asc") {
        return a[sortKey] > b[sortKey]
          ? 1
          : -1;
      }

      return a[sortKey] < b[sortKey]
        ? 1
        : -1;
    });
  }, [data, sortKey, sortOrder]);

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortOrder(
        sortOrder === "asc"
          ? "desc"
          : "asc"
      );
    } else {
      setSortKey(key);

      setSortOrder("asc");
    }
  };

  const handleSelectRow = (id) => {
    if (
      selectedRows.includes(id)
    ) {
      setSelectedRows(
        selectedRows.filter(
          (item) => item !== id
        )
      );
    } else {
      setSelectedRows([
        ...selectedRows,
        id,
      ]);
    }
  };

  if (loading) {
    return <TableLoader />;
  }

  if (!data.length) {
    return (
      <EmptyState title="No records found" />
    );
  }

  return (
    <div
      className="
        overflow-x-auto
        bg-white
        rounded-2xl
        shadow-sm
      "
    >
      <table className="w-full">
        <thead className="bg-gray-100">
          <tr>
            <th className="px-5 py-4">
              <input type="checkbox" />
            </th>

            {columns.map((column) => (
              <th
                key={column.key}
                onClick={() =>
                  handleSort(
                    column.key
                  )
                }
                className="
                  px-5 py-4
                  text-left
                  cursor-pointer
                "
              >
                <div className="flex items-center gap-2">
                  {column.title}

                  <FaSort />
                </div>
              </th>
            ))}

            {actions && (
              <th className="px-5 py-4">
                Actions
              </th>
            )}
          </tr>
        </thead>

        <tbody>
          {sortedData.map((row) => (
            <tr
              key={row.id}
              className="
                border-t
                hover:bg-gray-50
                transition-all
              "
            >
              <td className="px-5 py-4">
                <input
                  type="checkbox"
                  checked={selectedRows.includes(
                    row.id
                  )}
                  onChange={() =>
                    handleSelectRow(
                      row.id
                    )
                  }
                />
              </td>

              {columns.map(
                (column) => (
                  <td
                    key={
                      column.key
                    }
                    className="
                      px-5 py-4
                    "
                  >
                    {
                      row[
                        column.key
                      ]
                    }
                  </td>
                )
              )}

              {actions && (
                <td className="px-5 py-4">
                  <div className="flex gap-3">
                    <button
                      onClick={() =>
                        onEdit(
                          row
                        )
                      }
                      className="text-blue-600"
                    >
                      <FaEdit />
                    </button>

                    <button
                      onClick={() =>
                        onDelete(
                          row.id
                        )
                      }
                      className="text-red-600"
                    >
                      <FaTrash />
                    </button>
                  </div>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DataTable;