import {
  FaUsers,
  FaTasks,
  FaMoneyBill,
  FaProjectDiagram,
} from "react-icons/fa";

import DashboardCard from "../../components/dashboard/DashboardCard";

function AdminDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">
          Admin Dashboard
        </h1>

        <p className="text-gray-500">
          Welcome back Admin
        </p>
      </div>

      <div
        className="
          grid grid-cols-1
          md:grid-cols-2
          xl:grid-cols-4
          gap-6
        "
      >
        <DashboardCard
          title="Users"
          value="120"
          icon={<FaUsers />}
        />

        <DashboardCard
          title="Projects"
          value="35"
          icon={<FaProjectDiagram />}
        />

        <DashboardCard
          title="Tasks"
          value="540"
          icon={<FaTasks />}
        />

        <DashboardCard
          title="Expenses"
          value="$12K"
          icon={<FaMoneyBill />}
        />
      </div>
    </div>
  );
}

export default AdminDashboard;