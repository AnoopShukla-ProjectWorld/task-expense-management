import { useState } from "react";

import {
  useQuery,
} from "@tanstack/react-query";

import DataTable from "../../components/tables/DataTable";

import TableSearch from "../../components/tables/TableSearch";

import DashboardCard from "../../components/dashboard/DashboardCard";

import UserModal from "../../components/modals/UserModal";

import Button from "../../components/common/Button";

import {
  getUsers,
} from "../../services/userService";

function UsersPage() {
  const [search, setSearch] =
    useState("");

  const [isOpen, setIsOpen] =
    useState(false);

  const { data, isLoading } =
    useQuery({
      queryKey: ["users", search],

      queryFn: () =>
        getUsers(search),
    });

  const columns = [
    {
      key: "full_name",
      title: "Name",
    },

    {
      key: "email",
      title: "Email",
    },

    {
      key: "role_name",
      title: "Role",
    },

    {
      key: "status",
      title: "Status",
    },
  ];

  return (
    <div className="space-y-6">
      <div
        className="
          flex justify-between
          items-center
        "
      >
        <div>
          <h1 className="text-3xl font-bold">
            Users Management
          </h1>

          <p className="text-gray-500">
            Manage all system users
          </p>
        </div>

        <Button
          onClick={() =>
            setIsOpen(true)
          }
        >
          Create User
        </Button>
      </div>

      <div
        className="
          flex justify-between
          items-center
        "
      >
        <TableSearch
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />
      </div>

      <DataTable
        columns={columns}
        data={data || []}
        loading={isLoading}
      />

      <UserModal
        isOpen={isOpen}
        onClose={() =>
          setIsOpen(false)
        }
      />
    </div>
  );
}

export default UsersPage;