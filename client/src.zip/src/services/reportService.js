import axiosInstance from "../api/axios";

export const getAuditLogs = async () => {
  const response = await axiosInstance.get("/reports/audit-logs");
  return response.data.data;
};

export const getExpenseReport = async () => {
  const response = await axiosInstance.get("/reports/expenses");
  return response.data.data;
};